a=set()

for i in input().split():

if i not in a:

a.add(i)

print('NO')

else:

print('YES')
