a=set(input().split())

b=set(input().split())

print (len(a.intersection(b)))
